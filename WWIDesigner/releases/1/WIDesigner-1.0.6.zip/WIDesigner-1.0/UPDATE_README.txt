Updating a release

This release is an update fully compatible with other v1.0 releases.
If you have already installed such a release, you only need to
download the latest WIDesigner jar file.

Put this jar file in the WIDesigner-1.0 directory on your system.
If you made shortcuts, you will have to update them to point to
the new jar. And if you are on a UNIX/Linux system, perform the
steps in the UNIX_README file.