Installation README

This is a patch update distribution for WIDesigner. But because
a new program jar file (to fix a major Mac issue) has been
created and several sample files have been added to the Reed
Study, it is being distribute as a full install. All of the files
(instrument, tuning, and constraints) that you have used or made
with 1.0.3 or later releases are fully compatible with this release.

Download WIDesigner-2.0.1. Follow the instructions in the YouTube:
   http://youtu.be/nDlKJURdHfw

If you normally keep your working files in the installation
directory, you might want to copy them to the directory you just
created with this new release.

And if you are on a UNIX/Linux system, perform the
steps in the UNIX_README file.