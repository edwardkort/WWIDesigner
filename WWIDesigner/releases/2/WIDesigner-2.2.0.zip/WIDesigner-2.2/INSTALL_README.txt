Installation README

This is an upgrade distribution for WIDesigner. Because it
includes new library files, a full install is required. This
release also includes several bug fixes and enhancements, so
please read the release notes.

All of the files (instrument, tuning, and constraints) that you
have used or made with 1.0.3 or later releases are fully
compatible with this release.

Download WIDesigner-2.2.0. Follow the instructions in the YouTube:
   http://youtu.be/nDlKJURdHfw

If you normally keep your working files in the installation
directory, you might want to copy them to the directory you just
created with this new release.

And if you are on a UNIX/Linux system, perform the
steps in the UNIX_README file.